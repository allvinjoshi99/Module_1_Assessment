# Allvin Joshi Portfolio

Static portfolio website built with HTML, CSS and JavaScript.

## Files

- `index.html` - website structure/content
- `style.css` - responsive design and styling
- `script.js` - interactions, theme toggle, coding playground and contact form

## GitHub Pages

Put all three files in the root of your GitHub Pages repository.

Keep your existing `CNAME` file in the root:

    allvinjoshi99.com

## Before publishing

Replace these placeholders in `index.html` and `script.js`:

- `YOUR_EMAIL@example.com`
- LinkedIn `#`
- Sample project links
- Sample project descriptions

The contact form currently uses `mailto:`. It does not require a backend, but it opens the visitor's email application. For automatic email submission later, connect the form to an email/form service or your own API.
